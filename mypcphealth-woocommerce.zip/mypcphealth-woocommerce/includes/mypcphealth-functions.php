<?php

function mypcphealth_get_headers() {
    return [
        'account-id' => get_option('mypcphealth_account_id'),
        'secret' => get_option('mypcphealth_secret'),
        'Content-Type' => 'application/json'
    ];
}

function mypcphealth_request($endpoint, $data = [], $method = 'POST') {
    $url = 'https://mypcphealth.com/api/v2/' . $endpoint;
    $response = wp_remote_request($url, [
        'method' => $method,
        'headers' => mypcphealth_get_headers(),
        'body' => json_encode($data),
    ]);

    if (is_wp_error($response)) {
        mypcphealth_log_error('MyPCPHealth API Request Error: ' . $response->get_error_message());
        return ['success' => false, 'message' => $response->get_error_message()];
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (!$body['success']) {
        mypcphealth_log_error('MyPCPHealth API Response Error: ' . $body['message']);
    }

    return $body;
}

function mypcphealth_log_error($message) {
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log($message);
    }
}
function mypcphealth_create_patient($order) {
    $email = $order->get_billing_email();
    $user_id = email_exists($email);

    if (!$user_id) {
        $user_id = wc_create_new_customer(
            $email,
            $email,
            wp_generate_password()
        );

        if (is_wp_error($user_id)) {
            mypcphealth_log_error('Customer Creation Error: ' . $user_id->get_error_message());
            return ['success' => false, 'message' => $user_id->get_error_message()];
        }

        // Update user meta with billing information
        update_user_meta($user_id, 'first_name', $order->get_billing_first_name());
        update_user_meta($user_id, 'last_name', $order->get_billing_last_name());
        update_user_meta($user_id, 'billing_phone', $order->get_billing_phone());
        update_user_meta($user_id, 'billing_address_1', $order->get_billing_address_1());
        update_user_meta($user_id, 'billing_address_2', $order->get_billing_address_2());
        update_user_meta($user_id, 'billing_city', $order->get_billing_city());
        update_user_meta($user_id, 'billing_state', $order->get_billing_state());
        update_user_meta($user_id, 'billing_postcode', $order->get_billing_postcode());
        update_user_meta($user_id, 'billing_country', $order->get_billing_country());
        update_user_meta($user_id, '_billing_birth_date', get_post_meta($order->get_id(), '_billing_birth_date', true));
    }

    // Create patient in MyPCPHealth
    $data = [
        'external_id' => $order->get_id(),
        'first_name' => $order->get_billing_first_name(),
        'last_name' => $order->get_billing_last_name(),
        'phone_number' => $order->get_billing_phone(),
        'birth_date' => get_post_meta($order->get_id(), '_billing_birth_date', true),
    ];
    return mypcphealth_request('patients/create', $data);
}

function mypcphealth_update_patient($order) {
    $patient_id = get_post_meta($order->get_id(), 'mypcphealth_patient_id', true);

    if (!$patient_id) {
        return ['success' => false, 'message' => 'Patient ID not found'];
    }

    $data = [
        'first_name' => $order->get_billing_first_name(),
        'last_name' => $order->get_billing_last_name(),
        'phone_number' => $order->get_billing_phone(),
        'birth_date' => get_post_meta($order->get_id(), '_billing_birth_date', true),
    ];

    return mypcphealth_request('patients/update/' . $patient_id, $data, 'PUT');
}
function mypcphealth_create_prescription($order, $patient_id) {
    $data = [
        'external_id' => $order->get_id(),
        'reference_id' => 'REF-' . $order->get_id(),
        'external_patient_id' => $patient_id,
        'doctor_npi' => 'DOCTOR_NPI',
        'doctor_first_name' => 'DoctorFirstName',
        'doctor_last_name' => 'DoctorLastName',
        'medication_id' => 'MEDICATION_ID',
        'quantity' => 1,
        'instructions' => 'Take one daily',
    ];
    return mypcphealth_request('prescriptions/create', $data);
}

function mypcphealth_cancel_prescription($order) {
    $prescription_id = get_post_meta($order->get_id(), 'mypcphealth_prescription_id', true);

    if (!$prescription_id) {
        return ['success' => false, 'message' => 'Prescription ID not found'];
    }

    return mypcphealth_request('prescriptions/cancel/' . $prescription_id, [], 'DELETE');
}
function mypcphealth_create_fill($order, $prescription_ids) {
    $data = [
        'refill_external_id' => 'REFILL-' . $order->get_id(),
        'refill_reference_id' => 'REFILL-REF-' . $order->get_id(),
        'packaging_id' => 'PACKAGING_ID',
        'shipping_address1' => $order->get_shipping_address_1(),
        'shipping_address2' => $order->get_shipping_address_2(),
        'shipping_city' => $order->get_shipping_city(),
        'shipping_state' => $order->get_shipping_state(),
        'shipping_zip_code' => $order->get_shipping_postcode(),
        'carrier' => 'CarrierName',
        'shipping_method' => 'ShippingMethod',
        'prescriptions_external_ids' => $prescription_ids,
    ];
    return mypcphealth_request('fills/create', $data);
}

function mypcphealth_get_prescription_status($prescription_id) {
    return mypcphealth_request('prescriptions/status/' . $prescription_id, [], 'GET');
}
function mypcphealth_handle_order($order_id) {
    $order = wc_get_order($order_id);

    // Create patient
    $patient_response = mypcphealth_create_patient($order);

    if (!$patient_response['success']) {
        mypcphealth_log_error('Patient Creation Error: ' . $patient_response['message']);
        return;
    }

    $patient_id = $patient_response['patient']['id'];
    update_post_meta($order_id, 'mypcphealth_patient_id', $patient_id);

    // Create prescription
    $prescription_response = mypcphealth_create_prescription($order, $patient_id);

    if (!$prescription_response['success']) {
        mypcphealth_log_error('Prescription Creation Error: ' . $prescription_response['message']);
        return;
    }

    $prescription_id = $prescription_response['prescription']['id'];
    update_post_meta($order_id, 'mypcphealth_prescription_id', $prescription_id);

    // Create fill
    $fill_response = mypcphealth_create_fill($order, [$prescription_id]);

    if (!$fill_response['success']) {
        mypcphealth_log_error('Fill Creation Error: ' . $fill_response['message']);
    }
}

add_action('woocommerce_thankyou', 'mypcphealth_handle_order', 10, 1);

// Update patient details on customer update
add_action('profile_update', 'mypcphealth_handle_profile_update', 10, 2);
function mypcphealth_handle_profile_update($user_id, $old_user_data) {
    $user = get_userdata($user_id);
    $orders = wc_get_orders(['customer_id' => $user_id]);

    foreach ($orders as $order) {
        mypcphealth_update_patient($order);
    }
}

// Cancel prescription on order cancellation
add_action('woocommerce_order_status_cancelled', 'mypcphealth_handle_order_cancelled', 10, 1);
function mypcphealth_handle_order_cancelled($order_id) {
    mypcphealth_cancel_prescription(wc_get_order($order_id));
}
function mypcphealth_display_dashboard_content() {
    $prescriptions = mypcphealth_get_prescriptions();

    if (!$prescriptions['success']) {
        echo '<p>Error fetching prescriptions: ' . $prescriptions['message'] . '</p>';
        return;
    }

    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>Prescription ID</th><th>Patient Name</th><th>Status</th><th>Date</th></thead>';
    echo '<tbody>';
    foreach ($prescriptions['rows'] as $prescription) {
        echo '<tr>';
        echo '<td>' . esc_html($prescription['id']) . '</td>';
        echo '<td>' . esc_html($prescription['patient_name']) . '</td>';
        echo '<td>' . esc_html($prescription['status']) . '</td>';
        echo '<td>' . esc_html($prescription['created_at']) . '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
}

function mypcphealth_get_prescriptions() {
    return mypcphealth_request('prescriptions', [], 'GET');
}
